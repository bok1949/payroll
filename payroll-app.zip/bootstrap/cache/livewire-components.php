<?php return array (
  'create-payroll-form' => 'App\\Http\\Livewire\\CreatePayrollForm',
  'create-pdf-payroll' => 'App\\Http\\Livewire\\CreatePdfPayroll',
);