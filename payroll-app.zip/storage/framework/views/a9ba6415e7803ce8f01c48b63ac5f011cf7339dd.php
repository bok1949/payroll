<div>
    
    <form wire:submit.prevent="savePayroll">
        <?php echo csrf_field(); ?>
    <div class="container">
        <div class="row mt-2">
        
            <div class="col-md-4">
                
                <label for="" class="col-sm-12 col-form-label">Salesrep name</label> <br>
                <div class="col-sm-12">
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
                        <select wire:model="salesrepname" class="form-control">
                            <option value="">Select Salesrep</option>
                            <?php $__currentLoopData = $salesrep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sr->id); ?>"><?php echo e($sr->salesrep_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <?php $__errorArgs = ['salesrepname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-5">

                <label for="" class="col-sm-12 text-center col-form-label">Date Period</label>
                <div class="col-sm-12">
                    <div class="row">
                        <div class="col-sm-4">
                            <select wire:model="month" class="form-control">
                                <option value="">Select Month</option>
                                <option value="January">January</option>
                                <option value="February">February</option>
                                <option value="March">March</option>
                                <option value="April">April</option>
                                <option value="May">May</option>
                                <option value="June">June</option>
                                <option value="July">July</option>
                                <option value="August">August</option>
                                <option value="September">September</option>
                                <option value="October">October</option>
                                <option value="November">November</option>
                                <option value="December">December</option>
                            </select>
                            <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-sm-4">
                            <select wire:model="period" class="form-control">
                                <option value="">Select period</option>
                                <option value="1-15">1-15</option>
                                <option value="16-30">16-30</option>
                                <option value="16-31">16-31</option>
                            </select>
                            <?php $__errorArgs = ['period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-sm-4">
                            <select wire:model="year" class="form-control">
                                <option value="">Select Year</option>
                                <?php for($i = 2021; $i < 2099; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                            <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                    
            </div>
            
            <?php if($number_of_clients != null): ?>
                <div class="col-sm-3">
                    <label for="" class="col-sm-12 col-form-label">Opening Balance</label> <br>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-dollar-sign"></i></span>
                        <input type="number" wire:model="opening_balance" min="0" class="form-control" value="<?php echo e(old('bonuses')); ?>">
                    </div>
                    <?php $__errorArgs = ['opening_balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endif; ?>
            

        </div>

        <div class="row">
            
            <?php if($number_of_clients != null): ?>
                <div class="col-sm-2">
                    <label for="" class="col-sm-12 col-form-label">Leads Purchased:</label> <br>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-envelope"></i></span>
                        <input type="number" wire:model="lead_purchased" min="0" class="form-control" value="<?php echo e(old('bonuses')); ?>">
                    </div>
                    <?php $__errorArgs = ['lead_purchased'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-sm-2">
                    <label for="" class="col-sm-12 col-form-label">Issue Charge:</label> <br>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-dollar-sign"></i></span>
                        <input type="number" wire:model="issue_charge" min="0" class="form-control" value="<?php echo e(old('bonuses')); ?>">
                    </div>
                    <?php $__errorArgs = ['issue_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endif; ?>

            <div class="col-sm-2">
                <label for="" class="col-sm-12 col-form-label">Bonuses</label> <br>
                <div class="input-group">
                    <span class="input-group-text" id="basic-addon1"><i class="fas fa-dollar-sign"></i></span>
                    <input type="number" wire:model="bonuses" min="0" class="form-control" value="<?php echo e(old('bonuses')); ?>">
                </div>
                <?php $__errorArgs = ['bonuses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <?php if($number_of_clients != null): ?>
                <div class="col-sm-2">
                    <label for="" class="col-sm-12 col-form-label">Agency Release:</label> <br>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-dollar-sign"></i></span>
                        <input type="number" wire:model="agency_release" min="0" class="form-control" value="<?php echo e(old('bonuses')); ?>">
                    </div>
                    <?php $__errorArgs = ['agency_release'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endif; ?>
            <div class="col-sm-2">
                <label for="" class="col-sm-12 col-form-label">Number of Clients</label> <br>
                <div class="input-group">
                    <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
                    <input type="number" wire:model="number_of_clients" min="0" class="form-control" value="<?php echo e(old('clients_num')); ?>">
                </div>
                <?php $__errorArgs = ['number_of_clients'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
             
        </div>

        <?php if($number_of_clients != null): ?>
            <div class="row">
                <div class="col-sm-6 offset-3">
                    <label for="" class="col-sm-12 col-form-label">Client Name</label> <br>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
                        <input type="text" wire:model="client_name" class="form-control" value="<?php echo e(old('clients_num')); ?>">
                    </div>
                    <?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-2 offset-5">
                    <label for="" class="col-sm-12">Eliteinsure Commissions:</label> <br>
                    <div class="input-group ">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-dollar-sign"></i></span>
                        <input type="text" class="form-control" value="<?php echo e($eliteinsure_commissions); ?>" readonly wire:model="eliteinsure_commissions"/>
                        
                    </div>
                    <?php $__errorArgs = ['eliteinsure_commissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="row mt-2">
            <div class="col-sm-4 offset-4">
                <button type="submit" class="btn btn-block btn-danger form-control" wire:loading.attr="disabled">Create Payroll </button>
                
            </div>
        </div>

    </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\payroll\resources\views/livewire/create-payroll-form.blade.php ENDPATH**/ ?>