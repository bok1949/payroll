

<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">Onlineinsure Payroll System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-home"></i> Home</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link active dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i>Salesrep
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="<?php echo e(route('showallsalesrep')); ?>"><i class="fas fa-user-cog"></i> Salesrep Profile</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('add-salesrep')); ?>"><i class="fas fa-plus"></i> Add Salesrep Profile</a></li>
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('createpayroll')); ?>"><i class="fas fa-pencil-alt"></i> Create Payroll</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#"><i class="fas fa-file-pdf"></i> PDF's</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('logout')); ?>"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        
        <div class="row">
            <div class="col-md-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Adding Salesrep</li>
                    </ol>
                </nav>
            </div>
        </div>
        
        <h3 class="text-center">Adding Sales Representative</h3>
        <hr>
        <div class="row mt-2">
            <div class="col-md-8 offset-2">
                 <?php if(session()->has('success')): ?>
                    <div class="row ustify-content-md-center ">
                        <div class="col-md-12">
                            <span class="alert alert-success d-block text-center" role="alert">
                                <?php echo e(session('success')); ?> 
                            </span>
                        </div>
                    </div>  
                <?php endif; ?>
                <form action="<?php echo e(route('savesalesrepform')); ?>" method="POST">
                     <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="" class="col-sm-3 col-form-label">Salesrep name</label>
                        <div class="col-sm-9">
                            <input type="text" name="salesrepname" class="form-control" value="<?php echo e(old('salesrepname')); ?>">
                        </div>
                        <span class="text-danger"><?php $__errorArgs = ['salesrepname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group row mt-2">
                        <label for="" class="col-sm-3 col-form-label">Set Commission Percentage</label>
                        <div class="col-sm-2">
                            <input type="number" min=0 name="setcommission" class="form-control" value="<?php echo e(old('setcommission')); ?>">
                        </div>
                        
                        <label for="" class="col-sm-2 col-form-label">Tax Rate</label>
                        <div class="col-sm-2">
                            <input type="number" name="taxrate" min=0 class="form-control" value="<?php echo e(old('taxrate')); ?>">
                        </div>

                         <label for="" class="col-sm-1 col-form-label">Bonuses</label>
                        <div class="col-sm-2">
                            <input type="number" min=0 name="bonus" class="form-control" value="<?php echo e(old('bonus')); ?>">
                        </div>

                    </div>

                    <div class="form-group row mt-2">
                        <div class="col-sm-8 offset-2">
                            <button type="submit" class="btn btn-block btn-primary form-control">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\payroll\resources\views/dashboard/addsalesrep.blade.php ENDPATH**/ ?>